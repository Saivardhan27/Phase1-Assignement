
public class Class8 {
	public static void main(String[] args) {
		String s = "Mphasis is very good company ";
		String s1 = "Especially for freshers";
		StringBuilder sb = new StringBuilder();
		sb.append(s);
		sb.append(s1);
		System.out.println("Converted two strings into stringBuilder: "+"\n"+"\t"+sb);
		StringBuffer sbs = new StringBuffer();
		sbs.append(s);
		sbs.append(s1);
		System.out.println("Converted two strings into stringBuffer: "+"\n"+"\t"+sbs);
	}
}
