import java.util.HashSet;

class Student
{
	private String name;
	private String rollNum;
	public Student() {
		super();
	}
	public Student(String name, String rollNum) {
		super();
		this.name = name;
		this.rollNum = rollNum;
	}
	@Override
	public String toString() {
		return "Student [name=" + name + ", RollNum=" + rollNum + "]";
	}
	
}
public class Class7 {
	public static void main(String[] args) {
		
		HashSet<Student> hs = new HashSet<>();
		hs.add(new Student("Sai","Jn356543"));
		hs.add(new Student("umakanth","jn786977"));
		hs.add(new Student("Teja","1710406"));
		hs.stream().forEach(System.out::println);
	}
}
