import java.util.Scanner;

public class Class3 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter two numbers");
		double first = sc.nextDouble();
		double second = sc.nextDouble();
		System.out.println(add(first, second));
		System.out.println(sub(first, second));
		System.out.println(mul(first, second));
		System.out.println(div(first, second));
	}
	
	public static double add(double a,double b)
	{
		System.out.println("Addition of two numbers");
		return a+b;
	}
	public static double sub(double a,double b)
	{
		if(a<b) System.out.println("First value is smaller than second");
		System.out.println("Substraction of two numbers");
		return a-b;
	}
	public static double mul(double a,double b)
	{
		System.out.println("Multiplication of two numbers");
		return a*b;
	}
	public static double div(double a,double b)
	{
		double div = 0;
		try {
			 div = a/b;
		}catch (ArithmeticException e) {
			System.out.println("denominator is zero please enter again");
		}
		finally
		{
			System.out.println("Divison of two numbers");
		}
		return div;
	}
}
