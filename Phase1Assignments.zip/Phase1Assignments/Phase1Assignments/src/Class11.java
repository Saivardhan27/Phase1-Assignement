import java.util.Scanner;

public class Class11 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter string to search");
		String s = sc.next();
		System.out.println(search(s));
	}

	private static boolean search(String s) {
		String[] array = {"apple","bat","cat","dog","elephant","fox","gym","honey","ice","jug","ktm","lemon"};
		for(int i=0;i<array.length;i++)
		{
			if(s.equalsIgnoreCase(array[i])) return true;
		}
		return false;
	}

}
