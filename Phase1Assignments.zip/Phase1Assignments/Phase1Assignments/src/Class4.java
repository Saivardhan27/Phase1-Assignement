import java.util.Scanner;

public class Class4 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a num");
		int number = sc.nextInt();
		System.out.println(returnByte(number));
		System.out.println(returnDouble(number));
	}
	public static byte returnByte(int num)
	{
		return (byte)num;
	}
	public static short returnShort(int num)
	{
		return (short)num;
	}
	public static int returnInt(int num)
	{
		return num;
	}
	public static double returnDouble(int num)
	{
		return num;
	}
	public static long returnLong(int num)
	{
		return num;
	}
	public static float returnFloat(int num)
	{
		return num;
	}
}
