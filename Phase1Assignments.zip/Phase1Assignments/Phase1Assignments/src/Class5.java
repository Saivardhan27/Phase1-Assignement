import java.util.Scanner;

class Car
{
	private String name;
	private String regNo;
	public Car()
	{
		super();
	}
	public Car(String name, String regNo) {
		super();
		this.name = name;
		this.regNo = regNo;
	}
	@Override
	public String toString() {
		return "Car [name=" + name + ", RegNumber=" + regNo + "]";
	}
	
}
public class Class5 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter car name");
		String name = sc.next();
		System.out.println("Enter car Registration Number");
		String regNo = sc.next();
		new Car();
		System.out.println(new Car(name,regNo));
	}

}
