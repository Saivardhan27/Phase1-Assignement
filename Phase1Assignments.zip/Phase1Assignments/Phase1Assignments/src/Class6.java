import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.Stack;

public class Class6 {
	public static void main(String[] args) {
		int[] arr = {4,5,6,7,8,9};
		arrayList(arr);
		linkedList(arr);
		queue();
		hashSet();
	}

	public static void arrayList(int[] array) {
		ArrayList<Integer> arr = new ArrayList<>();
		for (int i = 0; i < array.length; i++) {
			arr.add(array[i]);
		}
		System.out.println("ArrayList " + arr);
		arr.remove(3);
//		arr.clear();
		arr.add(2, 35);
		System.out.println(arr);
	}

	public static void linkedList(int[] array) {
		LinkedList<Integer> li = new LinkedList<>();
		for (int i = 0; i < array.length; i++) {
			li.add(array[i]);
		}
		System.out.println("Linkedlist " + li);
		li.add(1, 12);
		li.addFirst(33);
		li.addLast(27);
		li.removeLast();
		System.out.println(li);
		System.out.println("First Value " + li.getFirst());
	}

	public static void stack() {
		Stack<String> stack = new Stack<String>();
		stack.push("Mphasis");
		stack.push("Sai");
		stack.push("Hyderabad");
		stack.push("Assignments");
		Iterator<String> itr = stack.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		stack.pop();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}

	public static void queue() {
		ArrayDeque<Integer> ard = new ArrayDeque<>();
		ard.push(20);
		ard.push(12);
		ard.push(33);
		ard.push(45);
		ard.push(56);
		System.out.println(ard);
		ard.clear();
		ard.addFirst(345);
		ard.addLast(875);
		ard.addFirst(908);
		ard.addLast(456);
		System.out.println(ard);
	}

	public static void hashSet() {
		HashSet<String> hs = new HashSet<String>();
		hs.add("Mphasis");
		hs.add("Sai");
		hs.add("Hyderabad");
		hs.add("Assignments");
		Iterator<String> itr = hs.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
