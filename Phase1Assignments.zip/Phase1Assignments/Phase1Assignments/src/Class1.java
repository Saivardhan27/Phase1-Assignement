import java.util.Scanner;

public class Class1 {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter a string");
		String string1 = sc.next();
		System.out.println(convertToInt(string1));
		System.out.println(convertToLong(string1));
		System.out.println(convertToDouble(string1));
		System.out.println(convertToFloat(string1));
		System.out.println(convertToBoolean(string1));
	}
	public static int convertToInt(String s)
	{
		return Integer.parseInt(s);
	}
	public static long convertToLong(String s)
	{
		return Long.parseLong(s);
	}
	public static double convertToDouble(String s)
	{
		return Double.parseDouble(s);
	}
	public static float convertToFloat(String s)
	{
		return Float.parseFloat(s);
	}
	public static boolean convertToBoolean(String s) {
	    return Boolean.parseBoolean(s);
	}
}
