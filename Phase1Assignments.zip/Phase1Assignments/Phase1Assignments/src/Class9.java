import java.util.Arrays;
import java.util.Scanner;

public class Class9 {
 public static void main(String[] args) {
	Scanner sc = new Scanner(System.in);
	System.out.println("Enter size of single dimesion array");
	int n = sc.nextInt();
	int[] single = new int[n];
	for(int i=0;i<n;i++)
	{
		System.out.println("Enter array values");
		single[i]=sc.nextInt();
	}
	System.out.println(Arrays.toString(single));
	System.out.println();
	System.out.println("Enter size of Multi dimesion array");
	int a = sc.nextInt();
	int b = sc.nextInt();
	int[][] multi = new int[a][b];
	for(int j=0;j<a;j++)
	{
		for(int k=0;k<b;k++)
		{
			System.out.println("Enter array values");
			multi[j][k]=sc.nextInt();
		}
	}
	System.out.println(Arrays.toString(multi));
	
}
}
